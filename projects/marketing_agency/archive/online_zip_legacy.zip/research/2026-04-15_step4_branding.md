# 4차 단가 — 브랜딩

> 조사일: 2026-04-15 | 조사자: 재원(jaewon)

| 소분류명 | 중분류 | 최저가 | 평균가 | 최고가 | 과금방식 | 계약단위 | 출처 URL |
|---------|--------|-------|-------|-------|---------|---------|---------|
| 회사명·상호명 네이밍 | 브랜드 네이밍 | 5만원 | 25만원 | 150만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EB%84%A4%EC%9D%B4%EB%B0%8D |
| 제품·서비스명 네이밍 | 브랜드 네이밍 | 5만원 | 25만원 | 100만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EB%84%A4%EC%9D%B4%EB%B0%8D |
| 프로젝트·캠페인명 네이밍 | 브랜드 네이밍 | 5만원 | 15만원 | 50만원 | 건당 | 1회성 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EB%84%A4%EC%9D%B4%EB%B0%8D |
| 도메인 적합성 검토 | 브랜드 네이밍 | 5만원 | 10만원 | 30만원 | 건당 | 1회성 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EB%84%A4%EC%9D%B4%EB%B0%8D |
| 상표 사전 조사 | 브랜드 네이밍 | 10만원 | 20만원 | 50만원 | 건당 | 1회성 | https://soomgo.com/prices/%EB%B8%8C%EB%9E%9C%EB%94%A9-%EB%84%A4%EC%9D%B4%EB%B0%8D-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 다국어·글로벌 네이밍 | 브랜드 네이밍 | 20만원 | 80만원 | 300만원 | 건당 | 프로젝트 | https://www.loud.kr/pricing/estimate/naming |
| AI 네이밍 서비스 | 브랜드 네이밍 | 3만원 | 10만원 | 30만원 | 건당 | 1회성 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EB%84%A4%EC%9D%B4%EB%B0%8D |
| 심볼마크 디자인 | 로고 디자인·CI 개발 | 5만원 | 15만원 | 100만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%A1%9C%EA%B3%A0-%EB%94%94%EC%9E%90%EC%9D%B8 |
| 워드마크 디자인 | 로고 디자인·CI 개발 | 5만원 | 12만원 | 80만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%A1%9C%EA%B3%A0-%EB%94%94%EC%9E%90%EC%9D%B8 |
| 컴비네이션마크 디자인 | 로고 디자인·CI 개발 | 8만원 | 20만원 | 150만원 | 건당 | 프로젝트 | https://soomgo.com/prices/%EB%A1%9C%EA%B3%A0-%EB%94%94%EC%9E%90%EC%9D%B8 |
| 모노그램 디자인 | 로고 디자인·CI 개발 | 5만원 | 15만원 | 80만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%A1%9C%EA%B3%A0-%EB%94%94%EC%9E%90%EC%9D%B8 |
| 엠블럼 디자인 | 로고 디자인·CI 개발 | 8만원 | 20만원 | 100만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%A1%9C%EA%B3%A0-%EB%94%94%EC%9E%90%EC%9D%B8 |
| 파비콘·앱아이콘 최적화 | 로고 디자인·CI 개발 | 3만원 | 8만원 | 30만원 | 건당 | 1회성 | https://soomgo.com/prices/%EB%A1%9C%EA%B3%A0-%EB%94%94%EC%9E%90%EC%9D%B8 |
| CI 매뉴얼 제작 | 로고 디자인·CI 개발 | 20만원 | 80만원 | 300만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EB%94%94%EC%9E%90%EC%9D%B8-%EA%B0%80%EC%9D%B4%EB%93%9C%EB%9D%BC%EC%9D%B8 |
| 브랜드 컬러 시스템 개발 | BI(Brand Identity) 시스템 구축 | 20만원 | 60만원 | 200만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 브랜드 타이포그래피 시스템 | BI(Brand Identity) 시스템 구축 | 20만원 | 50만원 | 150만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 브랜드 패턴·텍스처 개발 | BI(Brand Identity) 시스템 구축 | 20만원 | 50만원 | 150만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 브랜드 모션 가이드 | BI(Brand Identity) 시스템 구축 | 30만원 | 100만원 | 300만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%AA%A8%EC%85%98-%EA%B7%B8%EB%9E%98%ED%94%BD-%EC%A0%9C%EC%9E%91 |
| 브랜드 일러스트레이션 스타일 | BI(Brand Identity) 시스템 구축 | 30만원 | 80만원 | 300만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 브랜드 아이콘 시스템 | BI(Brand Identity) 시스템 구축 | 20만원 | 60만원 | 200만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| BI 통합 가이드라인 문서 | BI(Brand Identity) 시스템 구축 | 30만원 | 100만원 | 500만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EB%94%94%EC%9E%90%EC%9D%B8-%EA%B0%80%EC%9D%B4%EB%93%9C%EB%9D%BC%EC%9D%B8 |
| 브랜드 미션·비전·밸류 정의 | 브랜드 스토리·메시지 개발 | 10만원 | 50만원 | 150만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B9%84%EC%A0%84-%EB%AF%B8%EC%85%98-%EC%B4%88%EA%B8%B0-%EB%B8%8C%EB%9E%9C%EB%94%A9 |
| 브랜드 오리진 스토리 개발 | 브랜드 스토리·메시지 개발 | 10만원 | 30만원 | 100만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B9%84%EC%A0%84-%EB%AF%B8%EC%85%98-%EC%B4%88%EA%B8%B0-%EB%B8%8C%EB%9E%9C%EB%94%A9 |
| 핵심 메시지 아키텍처 설계 | 브랜드 스토리·메시지 개발 | 20만원 | 50만원 | 150만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B9%84%EC%A0%84-%EB%AF%B8%EC%85%98-%EC%B4%88%EA%B8%B0-%EB%B8%8C%EB%9E%9C%EB%94%A9 |
| 브랜드 보이스·톤 정의 | 브랜드 스토리·메시지 개발 | 20만원 | 50만원 | 150만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B9%84%EC%A0%84-%EB%AF%B8%EC%85%98-%EC%B4%88%EA%B8%B0-%EB%B8%8C%EB%9E%9C%EB%94%A9 |
| 카피 플랫폼 개발 | 브랜드 스토리·메시지 개발 | 20만원 | 80만원 | 300만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 브랜드 나레이티브 문서 | 브랜드 스토리·메시지 개발 | 20만원 | 50만원 | 200만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B9%84%EC%A0%84-%EB%AF%B8%EC%85%98-%EC%B4%88%EA%B8%B0-%EB%B8%8C%EB%9E%9C%EB%94%A9 |
| 기업 태그라인 개발 | 슬로건·태그라인 개발 | 5만원 | 25만원 | 80만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EB%84%A4%EC%9D%B4%EB%B0%8D |
| 제품·서비스 슬로건 개발 | 슬로건·태그라인 개발 | 5만원 | 20만원 | 60만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EB%84%A4%EC%9D%B4%EB%B0%8D |
| 캠페인 캐치프레이즈 개발 | 슬로건·태그라인 개발 | 5만원 | 15만원 | 50만원 | 건당 | 1회성 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EB%84%A4%EC%9D%B4%EB%B0%8D |
| 슬로건 다국어 현지화 | 슬로건·태그라인 개발 | 10만원 | 30만원 | 100만원 | 건당 | 1회성 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EB%84%A4%EC%9D%B4%EB%B0%8D |
| 슬로건 후보 테스트 | 슬로건·태그라인 개발 | 10만원 | 30만원 | 80만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 슬로건 등록·보호 검토 | 슬로건·태그라인 개발 | 10만원 | 25만원 | 80만원 | 건당 | 1회성 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EB%84%A4%EC%9D%B4%EB%B0%8D |
| 미니 가이드라인 제작 | 브랜드 가이드라인 제작 | 10만원 | 30만원 | 80만원 | 건당 | 1회성 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EB%94%94%EC%9E%90%EC%9D%B8-%EA%B0%80%EC%9D%B4%EB%93%9C%EB%9D%BC%EC%9D%B8 |
| 스탠다드 브랜드북 제작 | 브랜드 가이드라인 제작 | 30만원 | 100만원 | 300만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 풀 브랜드 가이드라인 제작 | 브랜드 가이드라인 제작 | 80만원 | 250만원 | 800만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 디지털 인터랙티브 가이드라인 | 브랜드 가이드라인 제작 | 50만원 | 150만원 | 500만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 직원용 브랜드 사용 매뉴얼 | 브랜드 가이드라인 제작 | 20만원 | 80만원 | 200만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EB%94%94%EC%9E%90%EC%9D%B8-%EA%B0%80%EC%9D%B4%EB%93%9C%EB%9D%BC%EC%9D%B8 |
| 협력사·에이전시용 에셋 패키지 | 브랜드 가이드라인 제작 | 10만원 | 30만원 | 100만원 | 건당 | 1회성 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EB%94%94%EC%9E%90%EC%9D%B8-%EA%B0%80%EC%9D%B4%EB%93%9C%EB%9D%BC%EC%9D%B8 |
| 1차 포장재 디자인 | 패키지·제품 디자인 | 20만원 | 50만원 | 200만원 | 건당 | 프로젝트 | https://kmong.com/prices/%ED%8C%A8%ED%82%A4%EC%A7%80-%EB%94%94%EC%9E%90%EC%9D%B8 |
| 2차 포장재 디자인 | 패키지·제품 디자인 | 20만원 | 35만원 | 150만원 | 건당 | 프로젝트 | https://kmong.com/prices/%ED%8C%A8%ED%82%A4%EC%A7%80-%EB%94%94%EC%9E%90%EC%9D%B8 |
| 패키지 구조 설계 | 패키지·제품 디자인 | 30만원 | 80만원 | 300만원 | 건당 | 프로젝트 | https://www.loud.kr/pricing/estimate/package |
| 라벨·스티커 디자인 | 패키지·제품 디자인 | 5만원 | 20만원 | 80만원 | 건당 | 프로젝트 | https://kmong.com/prices/%ED%8C%A8%ED%82%A4%EC%A7%80-%EB%94%94%EC%9E%90%EC%9D%B8 |
| 제품 외관 CMF 디자인 | 패키지·제품 디자인 | 50만원 | 200만원 | 800만원 | 건당 | 프로젝트 | https://www.loud.kr/pricing/estimate/product |
| 리테일 POP 디자인 | 패키지·제품 디자인 | 10만원 | 30만원 | 100만원 | 건당 | 1회성 | https://kmong.com/prices/%ED%8C%A8%ED%82%A4%EC%A7%80-%EB%94%94%EC%9E%90%EC%9D%B8 |
| 패키지 목업·시제품 제작 | 패키지·제품 디자인 | 10만원 | 30만원 | 100만원 | 건당 | 1회성 | https://www.loud.kr/pricing/estimate/package |
| 제품 카탈로그 디자인 | 브랜드 카탈로그·브로셔 제작 | 10만원 | 30만원 | 150만원 | 건당 | 프로젝트 | https://soomgo.com/prices/%EC%9D%B8%EC%87%84%EB%AC%BC-%EB%94%94%EC%9E%90%EC%9D%B8 |
| 기업 브로셔 디자인 | 브랜드 카탈로그·브로셔 제작 | 10만원 | 22만원 | 50만원 | 건당 | 프로젝트 | https://soomgo.com/prices/%EC%9D%B8%EC%87%84%EB%AC%BC-%EB%94%94%EC%9E%90%EC%9D%B8 |
| 리플렛·팜플렛 디자인 | 브랜드 카탈로그·브로셔 제작 | 5만원 | 10만원 | 30만원 | 건당 | 1회성 | https://www.loud.kr/pricing/estimate/brochure |
| 뉴스레터·매거진 편집디자인 | 브랜드 카탈로그·브로셔 제작 | 20만원 | 50만원 | 200만원 | 건당 | 월간 | https://soomgo.com/prices/%EC%9D%B8%EC%87%84%EB%AC%BC-%EB%94%94%EC%9E%90%EC%9D%B8 |
| 디지털 e-카탈로그 제작 | 브랜드 카탈로그·브로셔 제작 | 10만원 | 30만원 | 100만원 | 건당 | 프로젝트 | https://soomgo.com/prices/%EC%9D%B8%EC%87%84%EB%AC%BC-%EB%94%94%EC%9E%90%EC%9D%B8 |
| 전시·박람회 인쇄물 디자인 | 브랜드 카탈로그·브로셔 제작 | 10만원 | 25만원 | 80만원 | 건당 | 1회성 | https://soomgo.com/prices/%EC%9D%B8%EC%87%84%EB%AC%BC-%EB%94%94%EC%9E%90%EC%9D%B8 |
| 명함 디자인 (기본) | 명함·사무용품 디자인 | 3만원 | 4.4만원 | 6만원 | 건당 | 1회성 | https://soomgo.com/prices/%EB%AA%85%ED%95%A8-%EB%94%94%EC%9E%90%EC%9D%B8 |
| 명함 디자인 (특수 후가공) | 명함·사무용품 디자인 | 5만원 | 15만원 | 50만원 | 건당 | 1회성 | https://kmong.com/prices/%EB%AA%85%ED%95%A8-%EC%A0%9C%EC%9E%91 |
| 레터헤드·봉투 디자인 | 명함·사무용품 디자인 | 3만원 | 10만원 | 30만원 | 건당 | 1회성 | https://kmong.com/prices/%EB%AA%85%ED%95%A8-%EC%A0%9C%EC%9E%91 |
| 사원증·배지 디자인 | 명함·사무용품 디자인 | 3만원 | 8만원 | 20만원 | 건당 | 1회성 | https://kmong.com/prices/%EB%AA%85%ED%95%A8-%EC%A0%9C%EC%9E%91 |
| 사무용품 세트 디자인 | 명함·사무용품 디자인 | 20만원 | 50만원 | 150만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%AA%85%ED%95%A8-%EC%A0%9C%EC%9E%91 |
| 이메일 서명 디자인 | 명함·사무용품 디자인 | 2만원 | 5만원 | 15만원 | 건당 | 1회성 | https://kmong.com/category/10706 |
| 기업 소개 브랜드필름 | 브랜드 영상 (기업 소개·홍보 영상) | 150만원 | 800만원 | 3,000만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EC%97%85%EC%A2%85%EB%B3%84-%EC%98%81%EC%83%81 |
| 제품·서비스 홍보영상 | 브랜드 영상 (기업 소개·홍보 영상) | 30만원 | 150만원 | 1,000만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EC%98%81%EC%83%81%EA%B4%91%EA%B3%A0 |
| 인터뷰·다큐 형식 영상 | 브랜드 영상 (기업 소개·홍보 영상) | 50만원 | 200만원 | 1,000만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EC%97%85%EC%A2%85%EB%B3%84-%EC%98%81%EC%83%81 |
| 모션그래픽·인포그래픽 영상 | 브랜드 영상 (기업 소개·홍보 영상) | 30만원 | 150만원 | 500만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%AA%A8%EC%85%98-%EA%B7%B8%EB%9E%98%ED%94%BD-%EC%A0%9C%EC%9E%91 |
| SNS용 숏폼 브랜드 영상 | 브랜드 영상 (기업 소개·홍보 영상) | 2만원 | 13만원 | 50만원 | 건당 | 1회성 | https://kmong.com/prices/%EC%88%8F%ED%8F%BC-%EC%98%81%EC%83%81-%EC%A0%9C%EC%9E%91 |
| 3D 제품 영상 | 브랜드 영상 (기업 소개·홍보 영상) | 50만원 | 200만원 | 800만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%AA%A8%EC%85%98-%EA%B7%B8%EB%9E%98%ED%94%BD-%EC%A0%9C%EC%9E%91 |
| 행사·론칭 영상 | 브랜드 영상 (기업 소개·홍보 영상) | 50만원 | 300만원 | 1,500만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EC%97%85%EC%A2%85%EB%B3%84-%EC%98%81%EC%83%81 |
| 누끼컷 촬영 | 포토그래피·제품 촬영 (브랜드 감성) | 1.1만원 | 3.3만원 | 10만원 | 건당 | 1회성 | https://kmong.com/category/724 |
| 라이프스타일 연출컷 촬영 | 포토그래피·제품 촬영 (브랜드 감성) | 5만원 | 20만원 | 80만원 | 건당 | 1회성 | https://kmong.com/category/724 |
| 화장품·뷰티 전문 촬영 | 포토그래피·제품 촬영 (브랜드 감성) | 10만원 | 44만원 | 150만원 | 건당 | 프로젝트 | https://kmong.com/category/724 |
| 푸드·음료 전문 촬영 | 포토그래피·제품 촬영 (브랜드 감성) | 10만원 | 30만원 | 100만원 | 건당 | 프로젝트 | https://soomgo.com/prices/%EA%B8%B0%EC%97%85-%EC%83%81%EC%97%85%EC%9A%A9-%EC%82%AC%EC%A7%84-%EC%B4%AC%EC%98%81 |
| 모델 착용·룩북 촬영 | 포토그래피·제품 촬영 (브랜드 감성) | 20만원 | 80만원 | 300만원 | 건당 | 프로젝트 | https://kmong.com/category/724 |
| 브랜드 캠페인 화보 촬영 | 포토그래피·제품 촬영 (브랜드 감성) | 50만원 | 200만원 | 800만원 | 건당 | 프로젝트 | https://kmong.com/category/724 |
| AI 제품 사진 합성 | 포토그래피·제품 촬영 (브랜드 감성) | 3만원 | 10만원 | 30만원 | 건당 | 1회성 | https://kmong.com/category/724 |
| SNS 프로필 이미지·커버 디자인 | 브랜드 온라인 채널 통합 (SNS 프로필·배너) | 2만원 | 6만원 | 20만원 | 건당 | 1회성 | https://kmong.com/category/142 |
| 하이라이트 아이콘 세트 디자인 | 브랜드 온라인 채널 통합 (SNS 프로필·배너) | 2만원 | 5만원 | 15만원 | 건당 | 1회성 | https://kmong.com/category/142 |
| 유튜브 채널아트·썸네일 템플릿 | 브랜드 온라인 채널 통합 (SNS 프로필·배너) | 1만원 | 6만원 | 20만원 | 건당 | 1회성 | https://kmong.com/prices/%EC%9C%A0%ED%8A%9C%EB%B8%8C-%EC%8D%B8%EB%84%A4%EC%9D%BC-%EB%94%94%EC%9E%90%EC%9D%B8 |
| SNS 피드 그리드 디자인 | 브랜드 온라인 채널 통합 (SNS 프로필·배너) | 5만원 | 20만원 | 80만원 | 건당 | 프로젝트 | https://kmong.com/category/142 |
| 카카오채널·네이버 스마트스토어 브랜딩 | 브랜드 온라인 채널 통합 (SNS 프로필·배너) | 5만원 | 15만원 | 50만원 | 건당 | 1회성 | https://kmong.com/category/142 |
| 멀티채널 브랜드 일관성 가이드 | 브랜드 온라인 채널 통합 (SNS 프로필·배너) | 20만원 | 50만원 | 200만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 브랜드 진단 및 감사 | 리브랜딩 컨설팅 | 10만원 | 30만원 | 100만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 리브랜딩 전략 수립 | 리브랜딩 컨설팅 | 50만원 | 200만원 | 800만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 로고·비주얼 리뉴얼 | 리브랜딩 컨설팅 | 20만원 | 100만원 | 500만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 브랜드명 변경 프로젝트 | 리브랜딩 컨설팅 | 50만원 | 300만원 | 1,000만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 이해관계자 커뮤니케이션 플랜 | 리브랜딩 컨설팅 | 30만원 | 100만원 | 300만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 리브랜딩 런칭 캠페인 기획 | 리브랜딩 컨설팅 | 50만원 | 200만원 | 800만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 경쟁사 브랜드 벤치마킹 | 브랜드 포지셔닝·경쟁 분석 | 10만원 | 30만원 | 100만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 포지셔닝 맵 작성 | 브랜드 포지셔닝·경쟁 분석 | 10만원 | 25만원 | 80만원 | 건당 | 1회성 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 타겟 고객 인사이트 조사 | 브랜드 포지셔닝·경쟁 분석 | 20만원 | 80만원 | 300만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 브랜드 차별점(USP) 도출 | 브랜드 포지셔닝·경쟁 분석 | 10만원 | 30만원 | 100만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 포지셔닝 스테이트먼트 작성 | 브랜드 포지셔닝·경쟁 분석 | 10만원 | 25만원 | 80만원 | 건당 | 1회성 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |
| 브랜드 트래킹 조사 설계 | 브랜드 포지셔닝·경쟁 분석 | 30만원 | 100만원 | 500만원 | 건당 | 프로젝트 | https://kmong.com/prices/%EB%B8%8C%EB%9E%9C%EB%93%9C-%EC%BB%A8%EC%84%A4%ED%8C%85 |

---

## 조사 근거 요약

**크몽 (kmong.com/prices)**: 실거래 데이터 기반 분야별 평균 단가 제공. 브랜드 네이밍 평균 25만원, 로고 디자인 평균 12만원, 명함 제작 평균 5만원 수준. 최저~최고 범위 크게 분산.

**숨고 (soomgo.com/prices)**: 브랜딩/네이밍 컨설팅 평균 25만원 (최저 15만원, 최고 37만원). 로고 디자인 평균 10만원 (최저 5만원, 최고 30만원). 명함 디자인 평균 4.4만원. 인쇄물 디자인 평균 21.7만원 (최저 10만원, 최고 50만원).

**라우드소싱 (loud.kr/pricing/estimate)**: 네이밍 평균 단가 49.6만원. 패키지·포장 디자인, 브로셔·리플렛 별도 데이터 보유. 공모 방식으로 크몽·숨고보다 다소 높은 경향.

**드롭샷매치 (match.dropshot.io)**: 기업 홍보 영상 평균 1,500만원, 모션그래픽 평균 400만원. 에이전시 매칭 플랫폼 기준으로 프리랜서 플랫폼보다 높음.

**플로우웍스 (flowworks.io)**: 정찰제 단가표 운영. 단건·구독 모두 지원. 상세 단가는 flowworks.io/price/client 직접 확인 필요.
